Ticket-Management Using Go

Summary
 
This is a Ticket Management project. Here a user can raise a ticket and then an admin can see it and give response to it and then the user can close the ticket.


Platform Used

Front-End
(i) HTML5
(ii) CSS3
(iii) JavaScript

Back-End
(i) Go 
(ii) MongoDB
(iii) Go-jira Package
(iv) Oauth2 Package


Key Features

Signin User
(i) CreateTicket - To create a new ticket
(ii) MyTicket - To view all Tickets raised by current signedin user
(iii) GetTicket - To get details of a particular Ticket
(iv) ReopenTicket - To reopen a resolved ticket
(v) CloseTicket - To Close a resolved Ticket

Admin
(i) AllTicket  - To get All tickets lict based on category
(ii) GetTicket - To get a particular Ticket details
(iii) AdminResponse - To update ticket status and response from admin


Conclusion
These are some of the keyfeatures and also this micro service communicates with Go-Jira microservice to create and update a ticket in jira service management project.
