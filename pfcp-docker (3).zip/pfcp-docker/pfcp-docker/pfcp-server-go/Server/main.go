// Copyright 2019-2021 go-pfcp authors. All rights reserved.
// Use of this source code is governed by a MIT-style license that can be
// found in the LICENSE file.

// Command hb-server sends a HeartbeatRequest and checks response.
//
// Heartbeat exchanging feature is planned be included in the go-pfcp package's
// built-in functions in the future.
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/wmnsk/go-pfcp/ie"
	"github.com/wmnsk/go-pfcp/message"
)

type inp struct {
	Network     string `json:"network"` //network
	Direction   string `json:"direction"`
	Allow       string `json:"allow"`
	Deny        string `json:"deny"`
	Target      string `json:"target-tags"` // Target Tags
	Source      string `json:"source-ranges"`
	Destination string `json:"destination-ranges"`
}

var hbr_seq, asr_seq, ser_seq uint32 = 1, 1, 1
var rt time.Time = time.Now()
var pri uint8 = 0
var fseid uint64 = 0x3333333344444444
var seid uint64 = 0x3333333311223344
var pdr_id uint16 = 0x2710
var fteid uint32 = 0x11111111

func main() {
	var (
		listen = flag.String("-s", ":8805", "addr/port to listen on")
	)
	flag.Parse()

	laddr, err := net.ResolveUDPAddr("udp", *listen)
	if err != nil {
		log.Fatal(err)
	}

	conn, err := net.ListenUDP("udp", laddr)
	if err != nil {
		log.Fatal(err)
	}

	for {
		log.Printf("waiting for messages on: %s", laddr)
		buf := make([]byte, 2500)
		n, addr, err := conn.ReadFrom(buf)
		if err != nil {
			log.Fatal(err)
		}

		msg, err := message.Parse(buf[:n])
		if err != nil {
			log.Printf("ignored undecodable message: %x, error: %s", buf[:n], err)
			continue
		}

		switch buf[1] {
		case message.MsgTypeHeartbeatRequest:
			hbreq, ok := msg.(*message.HeartbeatRequest)
			if !ok {
				log.Printf("got unexpected message: %s, from: %s", msg.MessageTypeName(), GetDestIP(addr))
			}
			handleHeartbeatRequest(conn, addr, hbreq)
		case message.MsgTypeAssociationSetupRequest:
			assreq, ok := msg.(*message.AssociationSetupRequest)
			if !ok {
				log.Printf("got unexpected message: %s, from: %s", msg.MessageTypeName(), GetDestIP(addr))
			}
			handleAssociationSetupRequest(conn, laddr, addr, assreq)
		case message.MsgTypeSessionEstablishmentRequest:
			sessreq, ok := msg.(*message.SessionEstablishmentRequest)
			if !ok {
				log.Printf("got unexpected message: %s, from: %s", msg.MessageTypeName(), GetDestIP(addr))
			}
			handleSessionEstablishmentRequest(conn, laddr, addr, sessreq)
		default:
			log.Printf("got unexpected message: %s, from: %s", msg.MessageTypeName(), GetDestIP(addr))
		}
		continue
	}
}

func GetDestIP(addr net.Addr) string {
	return strings.Split(addr.String(), ":")[0]
}

func handleHeartbeatRequest(conn *net.UDPConn, addr net.Addr, hbreq *message.HeartbeatRequest) {
	log.Printf("got Heartbeat Request from: %s", GetDestIP(addr))

	hbres, err := message.NewHeartbeatResponse(hbr_seq, ie.NewRecoveryTimeStamp(rt)).Marshal()
	if err != nil {
		log.Fatal(err)
	}

	if _, err := conn.WriteTo(hbres, addr); err != nil {
		log.Fatal(err)
	}
	hbr_seq++
	log.Printf("sent Heartbeat Response to: %s", GetDestIP(addr))
}

func handleAssociationSetupRequest(conn *net.UDPConn, laddr *net.UDPAddr, addr net.Addr, assreq *message.AssociationSetupRequest) {
	log.Printf("got Association Setup Request from: %s", GetDestIP(addr))

	var rule inp
	var x string
	var body []byte
	for _, j := range assreq.IEs {
		if j.Type == ie.ActivatePredefinedRules {
			x, _ = j.ActivatePredefinedRules()
			fmt.Println(x)
			break
		}
	}
	err := json.Unmarshal([]byte(x), &rule)
	if err != nil {
		fmt.Println("ERROR while Unmarshalling Json: ", err)
		body = []byte("ERROR while Unmarshalling Json")
	} else {

		responseBody := bytes.NewBuffer([]byte(x))

		response, err := http.Post("http://34.135.79.144:8000/update", "application/json", responseBody)
		if err != nil {
			//fmt.Println("Error while updating Firewall")
			body = []byte("Error while updating Firewall")
			fmt.Println(string(body))
		} else {

			body, _ = ioutil.ReadAll(response.Body)
			fmt.Println("Firewall Updated with details \n", string(body))

		}

	}

	fmt.Println("HERE ABOVE")
	assres, err := message.NewAssociationSetupResponse(
		asr_seq,
		//ie.NewNodeID(strings.Split(laddr.String(), ":")[0], "", ""),
		//	ie.NewCause(ie.CauseRequestAccepted),
		ie.NewRecoveryTimeStamp(rt), //check the output of ie.NewActivatePredefinedRules("Hello Response")
		ie.NewUPFunctionFeatures(0x01, 0x02),
		// ie.NewAlternativeSMFIPAddress(net.ParseIP(""), net.ParseIP("2001::1")),
		//	ie.NewPFCPASRspFlags(0x01),
		ie.NewActivatePredefinedRules(string(body)),
	).Marshal()

	if err != nil {
		fmt.Println("Error in Messege")
		log.Fatal(err)

	}

	if _, err := conn.WriteTo(assres, addr); err != nil {
		log.Fatal(err)
	}
	asr_seq++
	log.Printf("sent Association Setup Response to: %s", GetDestIP(addr))
}

func handleSessionEstablishmentRequest(conn *net.UDPConn, laddr *net.UDPAddr, addr net.Addr, sessreq *message.SessionEstablishmentRequest) {
	log.Printf("got Session Establishment Request from: %s", GetDestIP(addr))

	sessres, err := message.NewSessionEstablishmentResponse(
		0, 0, seid, ser_seq, pri,
		ie.NewNodeID(strings.Split(laddr.String(), ":")[0], "", ""),
		ie.NewCause(ie.CauseRequestAccepted),
		ie.NewOffendingIE(ie.Cause),
		ie.NewFSEID(fseid, net.ParseIP(strings.Split(laddr.String(), ":")[0]), nil),
		ie.NewCreatedPDR(
			ie.NewPDRID(pdr_id),
			ie.NewFTEID(0x01, fteid, net.ParseIP(""), nil, 0),
			ie.NewUEIPAddress(0x02, "198.66.2.10", "", 0, 0),
		),
		ie.NewLoadControlInformation(ie.NewSequenceNumber(0x10000), ie.NewMetric(0x01)),
		ie.NewOverloadControlInformation(
			ie.NewSequenceNumber(0x44000),
			ie.NewMetric(0x01),
			ie.NewTimer(20*time.Hour),
			ie.NewOCIFlags(0x01),
		),
		ie.NewCreatedTrafficEndpoint(
			ie.NewTrafficEndpointID(0x01),
			ie.NewFTEID(0x01, fteid, net.ParseIP(""), nil, 0),
			ie.NewUEIPAddress(0x02, "168.44.0.1", "", 0, 0),
		),
	).Marshal()

	if err != nil {
		log.Fatal(err)
	}

	if _, err := conn.WriteTo(sessres, addr); err != nil {
		log.Fatal(err)
	}
	ser_seq++
	seid++
	fseid++
	pdr_id++
	fteid++
	log.Printf("sent Session Establishment Response to: %s", GetDestIP(addr))
}

